package net.tawacentral.roger.secrets;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}