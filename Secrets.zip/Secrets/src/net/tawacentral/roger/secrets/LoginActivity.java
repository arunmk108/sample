package net.tawacentral.roger.secrets;
import java.io.File;
import java.text.MessageFormat;
import java.util.ArrayList;

import javax.crypto.Cipher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class LoginActivity extends Activity implements TextWatcher {
private static final int DIALOG_RESET_PASSWORD = 1;
public static final String LOG_TAG = "Secrets";
private static ArrayList<Secret> secrets = null;
private boolean isFirstRun;
private boolean isValidatingPassword;
private String passwordString;
private Toast toast;
@Override
public void onCreate(Bundle savedInstanceState) {
Log.d(LOG_TAG, "LoginActivity.onCreate");
super.onCreate(savedInstanceState);
setContentView(R.layout.login);
EditText password = (EditText)findViewById(R.id.login_password);
password.setOnKeyListener(new View.OnKeyListener() {
@Override
public boolean onKey(View v, int keyCode, KeyEvent event) {
if (KeyEvent.KEYCODE_ENTER == keyCode) {
          if (KeyEvent.ACTION_UP == event.getAction())
            handlePasswordClick((TextView) v);

          return true;
        }

        return false;
      }
    });

    
    password.addTextChangedListener(this);
    
    FileUtils.cleanupDataFiles(this);
    Log.d(LOG_TAG, "LoginActivity.onCreate done");
  }

  
  @Override
  protected void onResume() {
    Log.d(LOG_TAG, "LoginActivity.onResume");
    super.onResume();

    

    passwordString = null;
    isValidatingPassword = false;
    
    
    isFirstRun = isFirstRun();
    TextView instructions = (TextView)findViewById(R.id.login_instructions);
    TextView strength = (TextView)findViewById(R.id.password_strength);
    if (isFirstRun) {
      instructions.setText(R.string.login_instruction_1);
      strength.setVisibility(TextView.VISIBLE);
    } else {
      instructions.setText("");
      strength.setVisibility(TextView.GONE);
    }

    
    TextView password = (TextView) findViewById(R.id.login_password);
    password.setText("");
    password.setHint(R.string.login_enter_password);
    Log.d(LOG_TAG, "LoginActivity.onResume done");
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.login_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    boolean handled = false;

    switch(item.getItemId()) {
      case R.id.reset_password:
        showDialog(DIALOG_RESET_PASSWORD);
        handled = true;
        break;
      default:
        break;
    }

    return handled;
  }

  @Override
  public Dialog onCreateDialog(int id) {
    Dialog dialog = null;

    switch (id) {
      case DIALOG_RESET_PASSWORD: {
        DialogInterface.OnClickListener listener =
            new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int which) {
                if (DialogInterface.BUTTON1 == which) {
                  
                  if (!FileUtils.deleteSecrets(LoginActivity.this))
                    showToast(R.string.error_reset_password, Toast.LENGTH_LONG);
                  else
                    secrets = null;

                  onResume();
                }
              }
            };
        dialog = new AlertDialog.Builder(this)
            .setTitle(R.string.login_menu_reset_password)
            .setIcon(android.R.drawable.ic_dialog_alert)
            .setMessage(R.string.login_menu_reset_password_message)
            .setPositiveButton(R.string.login_reset_password_pos, listener)
            .setNegativeButton(R.string.login_reset_password_neg, null)
            .create();
        }
        break;
      default:
        break;
    }

    return dialog;
  }

  
  @Override
  public void afterTextChanged(Editable s) {
  }
  @Override
  public void beforeTextChanged(
      CharSequence s, int start, int count, int after) {
  }

  @Override
  public void onTextChanged(CharSequence s, int start, int before, int count) {
    Log.d(LOG_TAG, "LoginActivity.onTextChanged");

    
    updatePasswordStrengthView(s.toString());
  }

  
  private boolean isFirstRun() {
    return !FileUtils.secretsExist(this);
  }

  
  private void handlePasswordClick(TextView passwordView) {
    Log.d(LOG_TAG, "LoginActivity.handlePasswordClick");

    
    if (null != secrets) {
      Log.d(LOG_TAG, "LoginActivity.handlePasswordClick ignoring");
      return;
    }
    
    
    String passwordString = passwordView.getText().toString();

    if (isFirstRun) {
      TextView instructions = (TextView)findViewById(R.id.login_instructions);
      TextView strength = (TextView)findViewById(R.id.password_strength);

      if (!isValidatingPassword) {
       
        instructions.setText(R.string.login_instruction_2);
        passwordView.setHint(R.string.login_validate_password);
        passwordView.setText("");
        strength.setVisibility(TextView.GONE);

        this.passwordString = passwordString;
        isValidatingPassword = true;
        return;
      } else {
        
        if (!passwordString.equals(this.passwordString)) {
          instructions.setText(R.string.login_instruction_1);
          strength.setVisibility(TextView.VISIBLE);
          passwordView.setHint(R.string.login_enter_password);
          passwordView.setText("");
          showToast(R.string.invalid_password, Toast.LENGTH_SHORT);

          this.passwordString = null;
          isValidatingPassword = false;
          return;
        }
      }
    }

    passwordView.setText("");

   
    FileUtils.SaltAndRounds pair = FileUtils.getSaltAndRounds(this,
        FileUtils.SECRETS_FILE_NAME);    
    SecurityUtils.saveCiphers(SecurityUtils.createCiphers(passwordString,
                                                          pair.salt,
                                                          pair.rounds));

    if (isFirstRun) {
      secrets = new ArrayList<Secret>();
      
      
      Cipher cipher = SecurityUtils.getEncryptionCipher();
      File file = getFileStreamPath(FileUtils.SECRETS_FILE_NAME);
      byte[] salt = SecurityUtils.getSalt();
      int rounds = SecurityUtils.getRounds();
      int err = FileUtils.saveSecrets(this, file, cipher, salt, rounds,
                                      secrets); 
      if (0 != err) {
        showToast(err, Toast.LENGTH_LONG);
        return;
      }
    } else {
      secrets = FileUtils.loadSecrets(this);
      if (null == secrets) {
        
        Cipher cipher2 = SecurityUtils.createDecryptionCipherV2(
            passwordString, pair.salt, pair.rounds);
        if (null != cipher2)
          secrets = FileUtils.loadSecretsV2(this, cipher2, pair.salt,
                                            pair.rounds);

        
        if (null == secrets) {
          Cipher cipher1 = SecurityUtils.createDecryptionCipherV1(
              passwordString);
          if (null != cipher1)
            secrets = FileUtils.loadSecretsV1(this, cipher1);
        }

        if (null == secrets) {
          
          showToast(R.string.invalid_password, Toast.LENGTH_LONG);
          return;
        }
      }
    }

    passwordString = null;
    Intent intent = new Intent(LoginActivity.this, SecretsListActivity.class);
    startActivity(intent);
    Log.d(LOG_TAG, "LoginActivity.handlePasswordClick done");
  }

  
  private void showToast(int message, int length) {
    if (null == toast) {
      toast = Toast.makeText(LoginActivity.this, message, length);
      toast.setGravity(Gravity.CENTER, 0, 0);
    } else {
      toast.setText(message);
    }

    toast.show();
  }
  
  
  private void updatePasswordStrengthView(String password) {
    
    TextView strengthView = (TextView)findViewById(R.id.password_strength);
    if (TextView.VISIBLE != strengthView.getVisibility())
      return;

        PasswordStrength str = PasswordStrength.calculateStrength(password);
    strengthView.setText(MessageFormat.format(
        getText(R.string.password_strength_caption).toString(),
        str.getText(this)));
    strengthView.setTextColor(str.getColor());
  }

  
  public static ArrayList<Secret> getSecrets() {
    return secrets;
  }

  
  public static void restoreSecrets(ArrayList<Secret> secrets) {
    
    LoginActivity.secrets.clear();
    LoginActivity.secrets.addAll(secrets);
  }
  
  
  public static void clearSecrets() {
    secrets = null;
    SecurityUtils.clearCiphers();
  }
}
