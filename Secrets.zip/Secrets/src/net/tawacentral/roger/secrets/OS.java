package net.tawacentral.roger.secrets;
import java.lang.reflect.Method;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Context;
import android.util.Log;
import android.view.InputDevice;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
 
public class OS {
  
  public static final String LOG_TAG = "OS";

   public static boolean isAndroid30() {
    return android.os.Build.VERSION.SDK_INT >= 11;
  }

  
  public static void hideSoftKeyboard(Context ctx, View view) {
    InputMethodManager manager = (InputMethodManager)
        ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
    if (null != manager)
      manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
  }

  
  public static void invalidateOptionsMenu(Activity activity) {
    if (!isAndroid30())
      return;

    try {
      Method m = activity.getClass().getMethod("invalidateOptionsMenu");
      m.invoke(activity);
    } catch (Exception ex) {
      Log.e(LOG_TAG, "invalidateOptionMenu", ex);
    }
  }

  
  public static void configureSearchView(Activity activity, Menu menu) {
    if (!isAndroid30())
      return;

    try {
      SearchManager sm = (SearchManager) activity.getSystemService(
          Context.SEARCH_SERVICE);
      if (null == sm)
        return;

      Method m = sm.getClass().getMethod("getSearchableInfo",
          android.content.ComponentName.class);
      Object si = m.invoke(sm, activity.getComponentName());

      MenuItem item = menu.findItem(R.id.list_search);
      m = item.getClass().getMethod("getActionView");
      View widget = (View) m.invoke(item);

      m = widget.getClass().getMethod("setSearchableInfo", si.getClass());
      m.invoke(widget, si);
    } catch (Exception ex) {
      Log.e(LOG_TAG, "configureSearchView", ex);
    }
  }

  
  public static boolean supportsScrollWheel() {
    int[] ids = InputDevice.getDeviceIds();
    for (int id : ids) {
      InputDevice device = InputDevice.getDevice(id);
      int sources = device.getSources();
      final int sourceTbOrDpad =
          InputDevice.SOURCE_TRACKBALL | InputDevice.SOURCE_DPAD;
      if (0 != (sources & sourceTbOrDpad))
        return true;
    }

    return false;
  }
}
