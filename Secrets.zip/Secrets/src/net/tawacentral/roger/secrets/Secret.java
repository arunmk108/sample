
package net.tawacentral.roger.secrets;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Secret implements Serializable {
  private static final long serialVersionUID = -116450416616138469L;
  private static final int TIMEOUT_MS = 60 * 1000;
  private static final int MAX_LOG_SIZE = 100;

  private String description;
  private String username;
  private String password;
  private String email;
  private String note;
  private ArrayList<LogEntry> access_log;

  
  public static final class LogEntry implements Serializable {
    private static final long serialVersionUID = -9024951856209882415L;

    
    public static final int CREATED = 1;
    public static final int VIEWED = 2;
    public static final int CHANGED = 3;
    public static final int EXPORTED = 4;

    private int type_;
    private long time_;

    
    LogEntry() {
      type_ = CREATED;
      time_ = System.currentTimeMillis();
    }

    
    public LogEntry(int type, long time) {
      this.type_ = type;
      this.time_ = time;
    }

    
    public int getType() {
      return type_;
    }

    
    public long getTime() {
      return time_;
    }
  }

  
  public Secret() {
    access_log = new ArrayList<LogEntry>();
    access_log.add(new LogEntry());
  }

  
  private void readObject(ObjectInputStream stream)
      throws IOException, ClassNotFoundException {
    stream.defaultReadObject();
  }
  
  public void setDescription(String description) {
    this.description = description;
  }
  public String getDescription() {
    return description;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getUsername() {
    return username;
  }

  
  public void setPassword(String password) {
    long now = System.currentTimeMillis();
    LogEntry entry = access_log.get(0);
    if (now - entry.getTime() < TIMEOUT_MS) {
      if (entry.getType() == LogEntry.VIEWED) {
        access_log.remove(0);
        access_log.add(0, new LogEntry(LogEntry.CHANGED, now));
      }
    } else {
      access_log.add(0, new LogEntry(LogEntry.CHANGED, entry.getTime()));
      pruneAccessLog();
    }

    this.password = password;
  }

  
  public String getPassword(boolean forExport) {
    // Don't add an entry to the access log if the last entry is within
    // 60 seconds of now.
    long now = System.currentTimeMillis();
    LogEntry entry = access_log.get(0);
    if (forExport || (now - entry.getTime() > TIMEOUT_MS)) {
      int type = forExport ? LogEntry.EXPORTED : LogEntry.VIEWED;
      access_log.add(0, new LogEntry(type, now));
      pruneAccessLog();
    }

    return password;
  }

  
  private void pruneAccessLog() {
   
    while(access_log.size() > MAX_LOG_SIZE) {
      // The "created" entry is always the first one in the list, and there
      // is only ever one.  So try to delete the second last item.
      int index = access_log.size() - 2;
      access_log.remove(index);
    }
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getEmail() {
    return email;
  }

  public void setNote(String note) {
    this.note = note;
  }

  public String getNote() {
    return note;
  }

 
  public List<LogEntry> getAccessLog() {
    return Collections.unmodifiableList(access_log);
  }

  
  public LogEntry getMostRecentAccess() {
    return access_log.get(0);
  }
}
