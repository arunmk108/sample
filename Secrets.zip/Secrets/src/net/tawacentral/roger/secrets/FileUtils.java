package net.tawacentral.roger.secrets;
import android.annotation.SuppressLint;
import android.app.backup.BackupAgentHelper;
import android.app.backup.BackupDataInput;
import android.app.backup.BackupDataOutput;
import android.app.backup.FileBackupHelper;
import android.app.backup.FullBackupDataOutput;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;

import net.tawacentral.roger.secrets.SecurityUtils.CipherInfo;


public class FileUtils {
  
  public static class SaltAndRounds {
    public SaltAndRounds(byte[] salt, int rounds) {
      this.salt = salt;
      this.rounds = rounds;
    }
    public byte[] salt;
    public int rounds;
  }

  
  public static final String PREFS_FILE_NAME = "backup";

  
  public static final String PREF_LAST_BACKUP_DATE = "last_backup_date";

  
  public static final String SECRETS_FILE_NAME = "secrets";

  
  public static final String SECRETS_FILE_NAME_SDCARD = "/sdcard/secrets";

  
  public static final String SECRETS_FILE_NAME_CSV = "/sdcard/secrets.csv";

  
  public static final String OI_SAFE_FILE_NAME_CSV = "/sdcard/oisafe.csv";

  private static final File SECRETS_FILE_CSV = new File(SECRETS_FILE_NAME_CSV);
  private static final File OI_SAFE_FILE_CSV = new File(OI_SAFE_FILE_NAME_CSV);

  
  public static final String COL_DESCRIPTION = "Description";
  public static final String COL_USERNAME = "Id";
  public static final String COL_PASSWORD = "PIN";
  public static final String COL_EMAIL = "Email";
  public static final String COL_NOTES= "Notes";

  private static final String EMPTY_STRING = "";
  private static final String INDENT = "   ";
  private static final String RP_PREFIX = "@";

  
  public static final String LOG_TAG = "Secrets.FileUtils";

  
  private static final Object lock = new Object();

  private static final byte[] SIGNATURE = {0x22, 0x34, 0x56, 0x79};

  
  public static boolean secretsExist(Context context) {
    
    String[] filenames = context.fileList();
    return filenames.length > 0;
  }

  /** Does the secrets restore file exist on the SD card? */
  public static boolean restoreFileExist() {
    File file = new File(SECRETS_FILE_NAME_SDCARD);
    return file.exists();
  }

  
  public static long getTimeOfLastOnlineBackup(Context ctx) {
    SharedPreferences prefs = ctx.getSharedPreferences(PREFS_FILE_NAME, 0);
    if (prefs == null)
      return 0;

    return prefs.getLong(PREF_LAST_BACKUP_DATE, 0);
  }

  
  public static boolean isOnlineBackupTooOld(Context ctx) {
    long now = System.currentTimeMillis();
    long lastSaved = getTimeOfLastOnlineBackup(ctx);
    long oneWeeks = 7 * 24 * 60 * 60 * 1000;  // One week.

    boolean isTooOld = (now - lastSaved) > oneWeeks;
    if (isTooOld) {
      
      ctx.getSharedPreferences(PREFS_FILE_NAME, 0).edit()
          .putLong(PREF_LAST_BACKUP_DATE, now).apply();
    }

    return isTooOld;
  }

  
  private static boolean isRestorePointTooOld(File file) {
    long lastModified = file.lastModified();
    long now = System.currentTimeMillis();
    long twoDays = 2 * 24 * 60 * 60 * 1000;  // 2 days.

    return (now - lastModified) > twoDays;
  }

  
  public static List<String> getRestorePoints(Context context) {
    String[] filenames = context.fileList();
    ArrayList<String> list = new ArrayList<String>(filenames.length + 1);
    if (restoreFileExist())
      list.add(SECRETS_FILE_NAME_SDCARD);

    for (String filename : filenames) {
      if (filename.startsWith(RP_PREFIX))
        list.add(filename);
    }

    return list;
  }

  
  public static void cleanupDataFiles(Context context) {
    Log.d(LOG_TAG, "FileUtils.cleanupDataFiles");
    synchronized (lock) {
      String[] filenames = context.fileList();
      int oldCount = filenames.length;
      boolean secretsFileExists = context.getFileStreamPath(SECRETS_FILE_NAME)
          .exists();

      
      {
        File mostRecent = null;
        int mostRecentIndex = -1;
        for (int i = 0; i < filenames.length; ++i) {
          String filename = filenames[i];
          if (-1 != filename.indexOf("new")) {
            context.deleteFile(filename);
            --oldCount;
            filenames[i] = null;
          } else if (filename.startsWith(RP_PREFIX)) {
            if (!secretsFileExists) {
              File f = context.getFileStreamPath(filename);
              if (null == mostRecent ||
                  f.lastModified() > mostRecent.lastModified()) {
                mostRecent = f;
                mostRecentIndex = i;
              }
            }
          } else {
            --oldCount;
            filenames[i] = null;
          }
        }

        
        if (null != mostRecent) {
          mostRecent.renameTo(context.getFileStreamPath(SECRETS_FILE_NAME));
          --oldCount;
          filenames[mostRecentIndex] = null;
        }
      }

      
      while (oldCount > 10) {
        File oldest = null;
        int oldestIndex = -1;

        for (int i = 0; i < filenames.length; ++i) {
          String filename = filenames[i];
          if (null == filename)
            continue;

          File f = context.getFileStreamPath(filename);
          if (null == oldest || f.lastModified() < oldest.lastModified()) {
            oldest = f;
            oldestIndex = i;
          }
        }

        if (null != oldest) {
          
          if (!FileUtils.isRestorePointTooOld(oldest))
            break;

          oldest.delete();
          --oldCount;
          filenames[oldestIndex] = null;
        }
      }
    }
  }

 
  public static SaltAndRounds getSaltAndRounds(Context context, String path) {
    // The salt is stored as a byte array at the start of the secrets file.
    FileInputStream input = null;
    try {
      input = SECRETS_FILE_NAME_SDCARD.equals(path)
          ? new FileInputStream(path)
          : context.openFileInput(path);
      return getSaltAndRounds(input);
    } catch (Exception ex) {
      Log.e(LOG_TAG, "getSaltAndRounds", ex);
    } finally {
      try {if (null != input) input.close();} catch (IOException ex) {}
    }
    return new SaltAndRounds(null, 0);
  }

  
  public static SaltAndRounds getSaltAndRounds(InputStream input)
      throws IOException {
    // The salt is stored as a byte array at the start of the secrets file.
    byte[] signature = new byte[SIGNATURE.length];
    byte[] salt = null;
    int rounds = 0;
    input.read(signature);
    if (Arrays.equals(signature, SIGNATURE)) {
      int length = input.read();
      salt = new byte[length];
      input.read(salt);
      rounds = input.read();
      if (rounds < 4 || rounds > 31) {
        salt = null;
        rounds = 0;
      }
    }

    return new SaltAndRounds(salt, rounds);
  }

  
  public static int saveSecrets(Context context,
                                File existing,
                                Cipher cipher,
                                byte[] salt,
                                int rounds,
                                List<Secret> secrets) {
    Log.d(LOG_TAG, "FileUtils.saveSecrets");
    synchronized (lock) {
      Log.d(LOG_TAG, "FileUtils.saveSecrets: got lock");

      
      String prefix = MessageFormat.format(RP_PREFIX +
          "{0,date,yy.MM.dd}-{0,time,HH:mm}", new Date(),
          null);
      File parent = existing.getParentFile();
      File tempn = new File(parent, "new");
      File tempo = new File(parent, prefix);
      for (int i = 0; tempn.exists() || tempo.exists(); ++i) {
        tempn = new File(parent, "new" + i);
        tempo = new File(parent, prefix + i);
      }
      
      ObjectOutputStream output = null;
      try {
        FileOutputStream fos = new FileOutputStream(tempn);
        writeSecrets(fos, cipher, salt, rounds, secrets);
      } catch (Exception ex) {
        Log.d(LOG_TAG, "FileUtils.saveSecrets: could not write secrets file");
        
        tempn.delete();
        return R.string.error_save_secrets;
      } finally {
        try {if (null != output) output.close();} catch (IOException ex) {}
      }

      
      if (existing.exists() && !existing.renameTo(tempo)) {
        Log.d(LOG_TAG, "FileUtils.saveSecrets: could not move existing file");
        tempn.delete();
        return R.string.error_cannot_move_existing;
      }

      
      if (!tempn.renameTo(existing)) {
        Log.d(LOG_TAG, "FileUtils.saveSecrets: could not move new file");
        tempo.renameTo(existing);
        tempn.delete();
        return R.string.error_cannot_move_new;
      }

      Log.d(LOG_TAG, "FileUtils.saveSecrets: done");
      return 0;
    }
  }

  
  public static boolean backupSecrets(Context context,
                                      Cipher cipher,
                                      byte[] salt,
                                      int rounds,
                                      List<Secret> secrets) {
    Log.d(LOG_TAG, "FileUtils.backupSecrets");

    if (null == cipher)
      return false;

    ObjectOutputStream output = null;
    boolean success = false;

    try {
      FileOutputStream fos = new FileOutputStream(SECRETS_FILE_NAME_SDCARD);
      writeSecrets(fos, cipher, salt, rounds, secrets);
      success = true;
    } catch (Exception ex) {
    } finally {
      try {if (null != output) output.close();} catch (IOException ex) {}
    }

    return success;
  }

  
  public static ArrayList<Secret> loadSecretsV1(Context context,
                                                Cipher cipher) {
    synchronized (lock) {
      return restoreSecretsV1(context, SECRETS_FILE_NAME, cipher);
    }
  }

  
  public static ArrayList<Secret> loadSecretsV2(Context context,
                                                Cipher cipher,
                                                byte[] salt,
                                                int rounds) {
    synchronized (lock) {
      ArrayList<Secret> secrets = null;
      InputStream input = null;

      try {
        input = context.openFileInput(SECRETS_FILE_NAME);
        secrets = readSecrets(input, cipher, salt, rounds);
      } catch (Exception ex) {
        Log.e(LOG_TAG, "loadSecretsV2", ex);
      } finally {
        try {if (null != input) input.close();} catch (IOException ex) {}
      }

      return secrets;
    }
  }

 
  public static ArrayList<Secret> loadSecrets(Context context) {
    Log.d(LOG_TAG, "FileUtils.loadSecrets");
    synchronized (lock) {
      Log.d(LOG_TAG, "FileUtils.loadSecrets: got lock");

      Cipher cipher = SecurityUtils.getDecryptionCipher();
      if (null == cipher)
        return null;

      ArrayList<Secret> secrets = null;
      InputStream input = null;

      try {
        input = context.openFileInput(SECRETS_FILE_NAME);
        secrets = readSecrets(input, cipher, SecurityUtils.getSalt(),
                              SecurityUtils.getRounds());
      } catch (Exception ex) {
        Log.e(LOG_TAG, "loadSecrets", ex);
      } finally {
        try {if (null != input) input.close();} catch (IOException ex) {}
      }

      Log.d(LOG_TAG, "FileUtils.loadSecrets: done");
      return secrets;
    }
  }

  
  @SuppressWarnings("unchecked")
  public static ArrayList<Secret> restoreSecretsV1(Context context,
                                                   String rp,
                                                   Cipher cipher) {
    if (null == cipher)
      return null;

    ArrayList<Secret> secrets = null;
    ObjectInputStream input = null;

    try {
      InputStream fis = SECRETS_FILE_NAME_SDCARD.equals(rp)
          ? new FileInputStream(rp)
          : context.openFileInput(rp);
      input = new ObjectInputStream(new CipherInputStream(fis, cipher));
      secrets = (ArrayList<Secret>) input.readObject();
    } catch (Exception ex) {
      Log.e(LOG_TAG, "restoreSecretsV1", ex);
    } finally {
      try {if (null != input) input.close();} catch (IOException ex) {}
    }

    return secrets;
  }

  
  public static ArrayList<Secret> restoreSecretsV2(Context context,
                                                   String rp,
                                                   Cipher cipher,
                                                   byte[] salt,
                                                   int rounds) {
    CipherInfo info = new CipherInfo();
    info.decryptCipher = cipher;
    info.salt = salt;
    info.rounds = rounds;
    return restoreSecrets(context, rp, info);
  }

 
  public static ArrayList<Secret> restoreSecrets(Context context,
                                                 String rp,
                                                 CipherInfo info) {
    Log.d(LOG_TAG, "FileUtils.restoreSecrets");

    ArrayList<Secret> secrets = null;
    InputStream input = null;

    try {
      input = SECRETS_FILE_NAME_SDCARD.equals(rp)
          ? new FileInputStream(rp)
          : context.openFileInput(rp);
      secrets = readSecrets(input, info.decryptCipher, info.salt, info.rounds);
    } catch (Exception ex) {
      Log.e(LOG_TAG, "restoreSecrets", ex);
    } finally {
      try {if (null != input) input.close();} catch (IOException ex) {}
    }

    return secrets;
  }

  
  private static void writeSecrets(OutputStream output,
                                   Cipher cipher,
                                   byte[] salt,
                                   int rounds,
                                   List<Secret> secrets) throws IOException {
    output.write(SIGNATURE);
    output.write(salt.length);
    output.write(salt);
    output.write(rounds);
    ObjectOutputStream oout = new ObjectOutputStream(
        new CipherOutputStream(output, cipher));
    try {
      oout.writeObject(secrets);
    } finally {
      try {if (null != oout) oout.close();} catch (IOException ex) {}
    }
  }

  
  @SuppressWarnings("unchecked")
  private static ArrayList<Secret> readSecrets(InputStream input,
                                               Cipher cipher,
                                               byte[] salt,
                                               int rounds)
      throws IOException, ClassNotFoundException {
    SaltAndRounds pair = getSaltAndRounds(input);
    if (!Arrays.equals(pair.salt, salt) || pair.rounds != rounds) {
      return null;
    }

    ObjectInputStream oin = new ObjectInputStream(
        new CipherInputStream(input, cipher));
    try {
      return (ArrayList<Secret>) oin.readObject();
    } finally {
      try {if (null != oin) oin.close();} catch (IOException ex) {}
    }
  }

  
  public static boolean deleteSecrets(Context context) {
    Log.d(LOG_TAG, "FileUtils.deleteSecrets");
    synchronized (lock) {
      String filenames[] = context.fileList();
      for (String filename : filenames) {
        context.deleteFile(filename);
      }
    }

    return true;
  }

 
  public static boolean exportSecrets(Context context,List<Secret> secrets) {
    
    String[] row = new String[] {
        COL_DESCRIPTION, COL_USERNAME, COL_PASSWORD, COL_EMAIL, COL_NOTES
    };
    CSVWriter writer = null;
    boolean success = false;

    try {
      writer = new CSVWriter(new FileWriter(SECRETS_FILE_NAME_CSV));

      
      writer.writeNext(row);

      
      for (Secret secret : secrets) {
        row[0] = secret.getDescription();
        row[1] = secret.getUsername();
        row[2] = secret.getPassword(true); 
        row[3] = secret.getEmail();
        row[4] = secret.getNote();

        
        writer.writeNext(row);
        success = true;
      }
    } catch (Exception ex) {
      Log.e(LOG_TAG, "exportSecrets", ex);
    } finally {
      try {if (null != writer) writer.close();} catch (IOException ex) {}
    }

    return success;
  }

  
  public static File getFileToImport() {
    boolean haveSecretsCsv = SECRETS_FILE_CSV.exists();
    boolean haveOiSafeCsv = OI_SAFE_FILE_CSV.exists();
    File file = null;

    if (haveSecretsCsv && haveOiSafeCsv) {
      if (SECRETS_FILE_CSV.lastModified() > OI_SAFE_FILE_CSV.lastModified()) {
        file = SECRETS_FILE_CSV;
      } else {
        file = OI_SAFE_FILE_CSV;
      }
    } else if (haveSecretsCsv) {
      file = SECRETS_FILE_CSV;
    } else if (haveOiSafeCsv) {
      file = OI_SAFE_FILE_CSV;
    }

    return file;
  }

 
  public static boolean importSecrets(Context context,
                                      File file,
                                      ArrayList<Secret> secrets) {
    secrets.clear();

    boolean isOiSafeCsv = false;
    boolean isSecretsScv = false;
    boolean success = false;
    CSVReader reader = null;

    try {
      reader = new CSVReader(new FileReader(file));

      
      String headers[] = reader.readNext();
      if (null != headers) {
        isSecretsScv = isSecretsCsv(headers);
        if (!isSecretsScv)
          isOiSafeCsv = isOiSafeCsv(headers);
      }

      
      for (;;) {
        String[] row = reader.readNext();
        if (null == row)
          break;

        Secret secret = new Secret();
        if (isOiSafeCsv) {
          secret.setDescription(row[1]);
          secret.setUsername(row[3]);
          secret.setPassword(row[4]);
          secret.setEmail(EMPTY_STRING);

          int approxMaxLength = row[0].length() + row[2].length() +
                                row[5].length() + 32;
          StringBuilder builder = new StringBuilder(approxMaxLength);
          builder.append(row[5]).append("\n\n");
          builder.append("Category: ").append(row[0]).append('\n');
          if (null != row[2] && row[2].length() > 0)
            builder.append("Website: ").append(row[2]).append('\n');

          secret.setNote(builder.toString());
        } else {
          
          secret.setDescription(row[0]);
          secret.setUsername(row[1]);
          secret.setPassword(row[2]);
          secret.setEmail(row[3]);
          secret.setNote(row[4]);
        }

        secrets.add(secret);
      }

      
      success = isOiSafeCsv || isSecretsScv;
    } catch (Exception ex) {
      Log.e(LOG_TAG, "importSecrets", ex);
    } finally {
      try {if (null != reader) reader.close();} catch (IOException ex) {}
    }

    return success;
  }

  
  private static boolean isOiSafeCsv(String[] headers) {
    if (headers[0].equalsIgnoreCase("Category") &&
        headers[1].equalsIgnoreCase("Description") &&
        headers[2].equalsIgnoreCase("Website") &&
        headers[3].equalsIgnoreCase("Username") &&
        headers[4].equalsIgnoreCase("Password") &&
        headers[5].equalsIgnoreCase("Notes"))
      return true;

    return false;
  }

 
  private static boolean isSecretsCsv(String[] headers) {
    if (headers[0].equalsIgnoreCase(COL_DESCRIPTION) &&
        headers[1].equalsIgnoreCase(COL_USERNAME) &&
        headers[2].equalsIgnoreCase(COL_PASSWORD) &&
        headers[3].equalsIgnoreCase(COL_EMAIL) &&
        headers[4].equalsIgnoreCase(COL_NOTES))
      return true;

    return false;
  }

  
  public static String getCsvFileNames() {
    StringBuilder builder = new StringBuilder();
    builder.append(INDENT).append(SECRETS_FILE_CSV.getName()).append('\n');
    builder.append(INDENT).append(OI_SAFE_FILE_CSV.getName());

    return builder.toString();
  }

  @SuppressLint("NewApi")
  static public class SecretsBackupAgent extends BackupAgentHelper {
    
    public static final String LOG_TAG_AGENT = "SecretsBackupAgent";

    
    private static final String KEY ="file";

    @Override
    public void onCreate() {
      Log.d(LOG_TAG_AGENT, "onCreate");

      FileBackupHelper helper = new FileBackupHelper(this,
          FileUtils.SECRETS_FILE_NAME);
      addHelper(KEY, helper);
    }

    @Override
    public void onBackup(ParcelFileDescriptor oldState,
                         BackupDataOutput data,
                         ParcelFileDescriptor newState) throws IOException {
      Log.d(LOG_TAG_AGENT, "onBackup");
      synchronized (lock) {
        super.onBackup(oldState, data, newState);
      }
      getSharedPreferences(PREFS_FILE_NAME, 0).edit()
          .putLong(PREF_LAST_BACKUP_DATE, System.currentTimeMillis()).apply();
    }

    @Override
    public void onRestore(BackupDataInput data,
                          int appVersionCode,
                          ParcelFileDescriptor newState)  throws IOException {
      Log.d(LOG_TAG_AGENT, "onRestore");
      synchronized (lock) {
        super.onRestore(data, appVersionCode, newState);
      }
    }

    @Override
    public void onDestroy() {
      Log.d(LOG_TAG_AGENT, "onDestroy");
      super.onDestroy();
    }

    @Override
    public void onFullBackup(FullBackupDataOutput data) throws IOException {
      Log.d(LOG_TAG_AGENT, "onFullBackup");
      super.onFullBackup(data);
    }

    @Override
    public void onRestoreFile(ParcelFileDescriptor data,
        long size,
        File destination,
        int type,
        long mode,
        long mtime) throws IOException {
      Log.d(LOG_TAG_AGENT, "onRestoreFile");
      super.onRestoreFile(data, size, destination, type, mode, mtime);
    }
  }
}
