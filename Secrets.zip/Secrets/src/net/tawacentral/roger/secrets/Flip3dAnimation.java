package net.tawacentral.roger.secrets;

import android.graphics.Camera;
import android.graphics.Matrix;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.Transformation;


public class Flip3dAnimation extends Animation {
  private Camera camera;
  private View view1;
  private View view2;
  private float centerX;
  private float centerY;
  private boolean forward;
  private boolean visibilitySwapped;

  
  Flip3dAnimation(View view1, View view2, int centerX, int centerY,
                  boolean forward) {
    this.view1 = view1;
    this.view2 = view2;
    this.centerX = centerX;
    this.centerY = centerY;
    this.forward = forward;
    
    setDuration(1000);
    setFillAfter(true);
    setInterpolator(new AccelerateDecelerateInterpolator());
  }
  
  @Override
  public void initialize(int width, int height, int parentWidth,
                         int parentHeight) {
    super.initialize(width, height, parentWidth, parentHeight);
    
    camera = new Camera();
  }

  @Override
  protected void applyTransformation(float interpolatedTime, Transformation t) {
    
    final double radians = Math.PI * interpolatedTime;
    float degrees = (float)(180.0 * radians / Math.PI);

    
    if (interpolatedTime >= 0.5f) {
      degrees -= 180.f;
      
      if (!visibilitySwapped) {
        if (forward) {
          view1.setVisibility(View.GONE);
          view2.setVisibility(View.VISIBLE);
        } else {
          view2.setVisibility(View.GONE);
          view1.setVisibility(View.VISIBLE);
        }
        
        visibilitySwapped = true;
      }
    }
    
    if (!forward)
      degrees = -degrees;
    
    final Matrix matrix = t.getMatrix();

    camera.save();
    camera.translate(0.0f, 0.0f, (float)(310.0 * Math.sin(radians)));
    camera.rotateY(degrees);
    camera.getMatrix(matrix);
    camera.restore();

    matrix.preTranslate(-centerX, -centerY);
    matrix.postTranslate(centerX, centerY);
  }
}
