
package net.tawacentral.roger.secrets;
import java.io.File;
import java.util.List;

import javax.crypto.Cipher;

import android.app.Service;
import android.app.backup.BackupManager;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;


public class SaveService extends Service {
  private static List<Secret> secrets;
  private static Cipher cipher;
  private static byte[] salt;
  private static int rounds;

  BackupManager backupManager;

  
  public static synchronized void execute(Context context,
                                          List<Secret> secrets,
                                          Cipher cipher,
                                          byte[] salt,
                                          int rounds) {
    SaveService.secrets = secrets;
    SaveService.cipher = cipher;
    SaveService.salt = salt;
    SaveService.rounds = rounds;

    Intent intent = new Intent(context, SaveService.class);
    context.startService(intent);
  }

  public SaveService() {
  }

  @Override
  public IBinder onBind(Intent arg0) {
    return null;
  }

  @Override
  public void onCreate() {
    super.onCreate();
    backupManager = new BackupManager(this);
  }

  @Override
  public void onDestroy() {
    super.onDestroy();
  }

  @Override
  public int onStartCommand(Intent intent, int flags, final int startId) {
    synchronized (SaveService.class) {
      final List<Secret> secrets = SaveService.secrets;
      final Cipher cipher = SaveService.cipher;
      final File file = getFileStreamPath(FileUtils.SECRETS_FILE_NAME);
      final byte[] salt = SaveService.salt;
      final int rounds = SaveService.rounds;

      SaveService.secrets = null;
      SaveService.cipher = null;
      SaveService.salt = null;
      SaveService.rounds = 0;

      if (null != secrets && null != cipher) {
        new Thread(new Runnable() {
          @Override
          public void run() {
            int r = FileUtils.saveSecrets(SaveService.this, file, cipher,
                                          salt, rounds, secrets);

            
            if (0 == r)
              backupManager.dataChanged();

          
            if (!FileUtils.restoreFileExist())
              FileUtils.backupSecrets(SaveService.this, cipher, salt, rounds,
                                      secrets);

            stopSelf(startId);
          }}, "saveSecrets").start();
      } else {
        stopSelf(startId);
      }
    }
    return START_STICKY;
  }
}
