

package net.tawacentral.roger.secrets;

import android.graphics.Color;


enum PasswordStrength {
  WEAK(R.string.password_strength_weak, Color.RED),
  MEDIUM(R.string.password_strength_medium,
         Color.argb(255, 220, 185, 0)),  // Orange
  STRONG(R.string.password_strength_strong, Color.YELLOW),
  VERY_STRONG(R.string.password_strength_very_strong,
              Color.argb(255, 170, 255, 0)),  // Chartreuse
  CRAZY_STRONG(R.string.password_strength_crazy_strong, Color.GREEN);

  PasswordStrength(int resId, int color) {
    this.resId = resId;
    this.color = color;
  }

  
  CharSequence getText(android.content.Context ctx) {
    return ctx.getText(resId);
  }

 
  int getColor() {
    return color;
  }

  
  static PasswordStrength calculateStrength(String password) {
    int currentScore = 0;
    boolean sawUpper = false;
    boolean sawLower = false;
    boolean sawDigit = false;
    boolean sawSpecial = false;

    
    if (password.length() > 6)
      currentScore += 1;

    
    for (int i = 0; i < password.length(); i++) {
      char c = password.charAt(i);
      if (!sawSpecial && !Character.isLetterOrDigit(c)) {
        currentScore += 1;
        sawSpecial = true;
      } else {
        if (!sawDigit && Character.isDigit(c)) {
          currentScore += 1;
          sawDigit = true;
        } else {
          if (!sawUpper || !sawLower) {
            if (Character.isUpperCase(c))
              sawUpper = true;
            else
              sawLower = true;
            if (sawUpper && sawLower)
              currentScore += 1;
          }
        }
      }
    }

    switch (currentScore) {
      case 0: return WEAK;
      case 1: return MEDIUM;
      case 2: return STRONG;
      case 3: return VERY_STRONG;
      case 4: return CRAZY_STRONG;
      default:  // Fall through.
    }
    
    return CRAZY_STRONG;
  }

  int resId;
  int color;
}
